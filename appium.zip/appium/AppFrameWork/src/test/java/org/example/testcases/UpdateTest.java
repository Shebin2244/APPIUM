package org.example.testcases;

import org.example.pageobjects.ReadPOM;
import org.example.pageobjects.UpdatePOM;
import org.example.pageobjects.crudPOM;
import org.example.utilities.AndroidBaseTest;
import org.testng.annotations.Test;

public class UpdateTest extends AndroidBaseTest {
	UpdatePOM crud;
	ReadPOM rpom;
	crudPOM createPom;

	@Test(priority = 1)
	public void start() {
		crud = new UpdatePOM(driver);
		crud.skip();
		rpom = new ReadPOM(driver);
		rpom.search();
	}

	@Test(priority = 2)
	public void clickEditButton() {
		crud.clickEditButton();
	}
	
	@Test(priority = 7)
	public void UpdateContactAdd() {
		createPom=new crudPOM(driver);
		createPom.setInputFieldsData("SHEBIN","P BIJU", "UST", "(999) 581-5252", "shebin2244@gmail.com");
    }
}
