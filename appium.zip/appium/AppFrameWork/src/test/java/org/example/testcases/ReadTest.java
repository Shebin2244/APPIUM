package org.example.testcases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.example.pageobjects.ReadPOM;
import org.example.utilities.AndroidBaseTest;
import org.testng.annotations.Test;

public class ReadTest extends AndroidBaseTest {
	ReadPOM crud;

	@Test(priority = 1)
	public void start() {
		crud = new ReadPOM(driver);
		crud.skip();
	}

	@Test(priority = 2)
	public void searchBarTest() {
		assertTrue(crud.searchBar());
	}

	@Test(priority = 3)
	public void searchTest() {
		crud.search();
	}

	@Test(priority = 4)
	public void searchResultTest() {
		List<String> contactDetails = new ArrayList<>();
		// Add the provided information to the list
		contactDetails.add("shebin p biju");
		contactDetails.add("UST");
		contactDetails.add("(999) 581-5251");
		contactDetails.add("shebin2244@gmail.com");
		assertEquals(crud.searchResult(), contactDetails);
	}

}
