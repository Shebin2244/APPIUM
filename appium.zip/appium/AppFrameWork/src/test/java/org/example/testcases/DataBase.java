package org.example.testcases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.testng.annotations.Test;

public class DataBase {
	

    private static final String DB_URL = "jdbc:mysql://localhost:3306/db_books";
    private static final String USER = "root";
    private static final String PASS = "root";

    // Establishes a connection to the database
    public Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(DB_URL, USER, PASS);
    }

    // Executes a query and returns the ResultSet
    public ResultSet executeQuery(String query) throws SQLException, ClassNotFoundException {
        Connection conn = getConnection();
        PreparedStatement pstmt = conn.prepareStatement(query);
        return pstmt.executeQuery();
    }

    // Closes the provided resources
    public void closeResources(Connection conn, PreparedStatement pstmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Example method to get data from a specific table
    public void getDataFromTable(String tableName) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String query = "SELECT * FROM " + tableName;

        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("AUID");
                String name = rs.getString("ANAME");
                // Process other columns as needed
                System.out.println("ID: " + id + ", Name: " + name);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
    }
    
    
    @Test
	 public static void main(String[] args) {
    	System.out.println("dasdA");
	        DataBase db = new DataBase();
	        db.getDataFromTable("authors");
	    }
}
