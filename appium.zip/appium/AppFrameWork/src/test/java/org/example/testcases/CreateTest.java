package org.example.testcases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;

import org.apache.commons.io.FileUtils;
import org.example.pageobjects.crudPOM;
import org.example.utilities.AndroidBaseTest;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;

public class CreateTest extends AndroidBaseTest {
	crudPOM crud;

//	@Test(priority = 1)
//	public void start() {
//		crud = new crudPOM(driver);
//		crud.skip();
//	}
//
//	@Test(priority = 2)
//	public void contactTitleTest() {
//		assertEquals(crud.contactTitle(), "Contacts");
//	}
//
//	@Test(priority = 3)
//	public void checkAddButtonAndaddContactTest() {
//		assertTrue(crud.addButton());
//		crud.clickContacts();
//	}
//
//	@Test(priority = 4)
//	public void createContactTest() {
//		assertEquals(crud.createContactTitle(), "Create contact");
//	}
//
//	@Test(priority = 5)
//	public void addImageTest() {
//		crud.addImage();
//	}

	@Test(priority = 6, enabled = false)
	public void addContactDetailsTest() {
		Faker faker = new Faker();
		String firstName = faker.name().firstName();
		String lastName = faker.name().lastName();
		String company = faker.company().name();
		String phoneNumber = faker.phoneNumber().cellPhone();
		String email = faker.internet().emailAddress();
		crud.setInputFieldsData(firstName, lastName, company, phoneNumber, email);
	}

	@Test
	public void test() throws IOException {
		HashMap<String, String> data = getJsonData(
				System.getProperty("user.dir") + "\\src\\main\\resources\\contactData.json");

		printJsonData(data);
	}

	public HashMap<String, String> getJsonData(String jsonFilePath) throws IOException {
		String jsonContent = FileUtils.readFileToString(new File(jsonFilePath), StandardCharsets.UTF_8);
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String, String> data = mapper.readValue(jsonContent, new TypeReference<HashMap<String, String>>() {
		});
		return data;
	}

	public void printJsonData(HashMap<String, String> data) {
		for (String key : data.keySet()) {
			System.out.println(key + " = " + data.get(key));
		}
	}

	@Test(priority = 7, enabled = false)
	public void myContactAdd() {
		crud.setInputFieldsData("shebin", "p biju", "UST", "(999) 581-5251", "shebin2244@gmail.com");
	}

}
