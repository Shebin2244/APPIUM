package org.example.testcases;

import org.example.pageobjects.DeletePOM;
import org.example.pageobjects.ReadPOM;
import org.example.utilities.AndroidBaseTest;
import org.testng.annotations.Test;

public class DeleteTest extends AndroidBaseTest {
	ReadPOM rpom;
	DeletePOM dpom;

	@Test(priority = 1)
	public void start() {
		rpom = new ReadPOM(driver);
		rpom.skip();
		rpom.search();
	}
	@Test(priority = 2)
    public void setting() {
		dpom=new DeletePOM(driver);
		dpom.clickSettings();
    }
	@Test(priority = 3)
	public void delete() {
        dpom.delete();
    }
}
