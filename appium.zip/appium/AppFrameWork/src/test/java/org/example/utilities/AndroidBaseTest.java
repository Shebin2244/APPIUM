package org.example.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.DeviceRotation;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class AndroidBaseTest {
	public AndroidDriver driver;

	@BeforeTest
	public AndroidDriver ConfigureAppium() throws IOException, InterruptedException {

		// Load properties
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(
				System.getProperty("user.dir") + "\\src\\main\\java\\org\\example\\resources\\data.properties");
		prop.load(fis);
		// Configure Appium options and initialize driver
		String ipAddress = prop.getProperty("ipAddress");
		String port = prop.getProperty("port");

		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName(prop.getProperty("AndroidDeviceName"));
		if (Boolean.parseBoolean(prop.getProperty("appUsingPath"))) {
			options.setApp(System.getProperty("user.dir") + prop.getProperty("appPath"));
		} else {
			options.setAppPackage(prop.getProperty("appPackage"));
			options.setAppActivity(prop.getProperty("appActivity"));
		}

		driver = new AndroidDriver(new URL("http://" + ipAddress + ":" + port), options);
		DeviceRotation device = new DeviceRotation(0, 0, 270);
		driver.rotate(device);

		return driver;
	}

}
