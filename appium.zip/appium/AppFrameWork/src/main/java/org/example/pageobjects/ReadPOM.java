package org.example.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.example.utilities.ReusableFunctions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ReadPOM {
	private AndroidDriver driver;
	ReusableFunctions rf;

	public ReadPOM(AndroidDriver driver) {
		this.driver = driver;
		rf = new ReusableFunctions(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Finds the skip button by its id and allows it to be clicked
	@FindBy(id = "android:id/button2")
	WebElement skipButton;

	// Finds the allow button by its accessibility id and allows it to be clicked
	@AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_button")
	WebElement allowButton;

	@AndroidFindBy(id = "com.google.android.contacts:id/open_search_bar")
	WebElement openSearchBar;

	@AndroidFindBy(id = "com.google.android.contacts:id/open_search_bar_text_view")
	WebElement search;

	@AndroidFindBy(id = "com.google.android.contacts:id/large_title")
	WebElement namElement;

	@AndroidFindBy(id = "com.google.android.contacts:id/organization_name")
	WebElement organizationElement;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@content-desc=\"Call Mobile (999) 581-5251\"]/android.widget.RelativeLayout/android.widget.TextView[1]")
	WebElement contactElement;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@content-desc=\"Email Home shebin2244@gmail.com\"]/android.widget.RelativeLayout/android.widget.TextView[1]")
	WebElement emailElement;

	// Method to skip the permission and allow button
	public void skip() {
		rf.clickOnElement(skipButton);
		rf.takeADelay(2);
		rf.clickOnElement(allowButton);
	}

	public void search() {
		rf.takeADelay(3);
		rf.tapByCoordinates(350, 222);
		// name entering "shebin"
		rf.takeADelay(3);
		rf.tapByCoordinates(223, 1849);
		rf.tapByCoordinates(651, 1845);
		rf.tapByCoordinates(282, 1719);
		rf.tapByCoordinates(660, 1975);
		rf.tapByCoordinates(807, 1698);
		rf.tapByCoordinates(752, 1979);

		rf.takeADelay(2);
		//click on the listed contact
		rf.tapByCoordinates(287, 419);
	}

	public boolean searchBar() {
		return rf.isDisplayed(openSearchBar);
	}

	public List<String> searchResult() {
		List<String> detailsList = new ArrayList<String>();
		detailsList.add(rf.ReturnGetText(namElement));
		detailsList.add(rf.ReturnGetText(organizationElement));
		detailsList.add(rf.ReturnGetText(contactElement));
		detailsList.add(rf.ReturnGetText(emailElement));
		return detailsList;
	}
}
