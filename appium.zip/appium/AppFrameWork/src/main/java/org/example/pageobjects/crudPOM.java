package org.example.pageobjects;

import org.example.utilities.ReusableFunctions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class crudPOM {
	private AndroidDriver driver;
	ReusableFunctions rf;

	public crudPOM(AndroidDriver driver) {
		this.driver = driver;
		rf = new ReusableFunctions(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Finds the skip button by its id and allows it to be clicked
	@FindBy(id = "android:id/button2")
	WebElement skipButton;

	// Finds the allow button by its accessibility id and allows it to be clicked
	@AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_button")
	WebElement allowButton;

	// Finds the contact title element by its id and allows it to be interacted with
	@AndroidFindBy(id = "com.google.android.contacts:id/navigation_bar_item_large_label_view")
	WebElement contactTitlElement;

	// Finds the add button by its accessibility id and allows it to be clicked
	@AndroidFindBy(accessibility = "Create contact")
	WebElement addButton;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.LinearLayout/android.view.ViewGroup/android.widget.TextView")
	WebElement createTitleElement;

	@AndroidFindBy(id = "com.google.android.contacts:id/photo")
	WebElement createPhotoElement;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.support.v7.widget.LinearLayoutCompat/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")
	WebElement choosePhotoElement;

//	@AndroidBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout/android.widget.TextView[1]")
//	WebElement imageElement;

	@AndroidFindBy(accessibility = "Photo taken on May 23, 2024 9:46:49 AM")
	WebElement photoTakenElement;

	@AndroidFindBy(id = "com.google.android.apps.photos:id/photos_photoeditor_fragments_editor3_save")
	WebElement saveButton;

	// Method to skip the permission and allow button
	public void skip() {
		rf.clickOnElement(skipButton);
		rf.takeADelay(2);
		rf.clickOnElement(allowButton);
	}

	// Method to get the title of the contact
	public String contactTitle() {
		return rf.ReturnGetText(contactTitlElement);
	}

	// Method to click on the contacts button
	public void clickContacts() {
		rf.clickOnElement(addButton);
	}

	// Method to check if the add button is displayed
	public boolean addButton() {
		return rf.isDisplayed(addButton);
	}

	public String createContactTitle() {
		return rf.ReturnGetText(createTitleElement);
	}

	public void addImage() {
		rf.clickOnElement(createPhotoElement);
		rf.clickOnElement(choosePhotoElement);
		rf.tapByCoordinates(136, 599);
		rf.takeADelay(2);
		rf.tapByCoordinates(100, 600);
		rf.clickOnElement(saveButton);
		rf.takeADelay(10);
	}

	// Method to set text for multiple input fields dynamically
	public void setInputFieldsData(String... data) {
		for (int i = 0; i < data.length; i++) {
			driver.findElements(AppiumBy.className("android.widget.EditText")).get(i).sendKeys(data[i]);
		}
		rf.takeADelay(2);
		rf.tapByCoordinates(834, 222);
	}
}
