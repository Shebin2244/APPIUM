package org.example.pageobjects;

import org.example.utilities.ReusableFunctions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class UpdatePOM {
	private AndroidDriver driver;
	ReusableFunctions rf;

	public UpdatePOM(AndroidDriver driver) {
		this.driver = driver;
		rf = new ReusableFunctions(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Finds the skip button by its id and allows it to be clicked
	@FindBy(id = "android:id/button2")
	WebElement skipButton;

	// Finds the allow button by its accessibility id and allows it to be clicked
	@AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_button")
	WebElement allowButton;

	// Method to skip the permission and allow button
	public void skip() {
		rf.clickOnElement(skipButton);
		rf.takeADelay(2);
		rf.clickOnElement(allowButton);
	}

	public void clickEditButton() {
		rf.tapByCoordinates(842, 2156);
	}
}
