package org.example.pageobjects;

import org.example.utilities.ReusableFunctions;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class DeletePOM {
	private AndroidDriver driver;
	ReusableFunctions rf;

	public DeletePOM(AndroidDriver driver) {
		this.driver = driver;
		rf = new ReusableFunctions(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public void clickSettings() {
		rf.takeADelay(3);
		rf.tapByCoordinates(1006, 234);
	}

	public void delete() {
		rf.takeADelay(3);
		rf.tapByCoordinates(626, 382);
		rf.tapByCoordinates(830, 1355);
	}

}
