package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class FileIO {
	public static Properties properties;

	// This method loads properties from a file and returns a Properties object
	public static Properties getProperties(String fileName) {
		// Initialize the Properties object
		properties = new Properties();
		try {
			// Create a FileInputStream to read the properties file
			FileInputStream stream = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/" + fileName + ".properties");
			// Load properties from the input stream
			properties.load(stream);
		} catch (IOException e) {
			// Print stack trace if an IOException occurs
			e.printStackTrace();
		}
		// Return the loaded properties
		return properties;
	}
}
