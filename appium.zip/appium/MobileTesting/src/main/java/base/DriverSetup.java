package base;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.testng.annotations.BeforeTest;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class DriverSetup {
	public AndroidDriver driver;
	UiAutomator2Options options;
	protected ReusableFunction rf;

	// This method will run before any test method in the suite
	@BeforeTest
	public void setUp() throws MalformedURLException {
		// Initialize ReusableFunction class instance
		rf = new ReusableFunction();
		// Initialize UiAutomator2Options instance for setting up driver options
		options = new UiAutomator2Options();

		// Set device name and platform name using properties from ReusableFunction
		options.setDeviceName(rf.getPropertyValue("deviceName"));
		options.setPlatformName(rf.getPropertyValue("platformName"));

		// Check if the app is already installed or needs to be installed via APK
		if (rf.getPropertyValue("appType").equals("installed")) {
			// Set the path to the app's APK file
			options.setApp((rf.getPropertyValue("app")));
		} else {
			// Set the app package and activity for an installed app
			options.setAppPackage(rf.getPropertyValue("appPackage"));
			options.setAppActivity(rf.getPropertyValue("appActivity"));
		}

		// Initialize the AndroidDriver with the Appium server URL and options
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), options);
		// Set an implicit wait time of 20 seconds for finding elements
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
}
