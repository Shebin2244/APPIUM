package base;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager implements ITestListener {

	public ExtentSparkReporter sparkReporter; // ExtentSparkReporter instance to generate HTML reports
	public ExtentReports extent; // ExtentReports instance to manage reports
	public ExtentTest test; // ExtentTest instance to represent a test

	String repname; // Name of the report

	// Method executed before the start of the test
	public void onStart(ITestContext context) {
		// Define the date format pattern
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");

		// Get the current date and time
		Date now = new Date();

		// Format the current date and time
		String formattedDate = formatter.format(now);

		// Set the report name with the current date and time
		String repname = "AccountCreationReport_" + formattedDate + ".html";
		// Initialize ExtentSparkReporter with output directory and report name
		sparkReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "/TestNG_Reports/" + repname);
		sparkReporter.config().setReportName("UiAssesment Report"); // Set the report name
		sparkReporter.config().setDocumentTitle("UiAssesment Document"); // Set the document title
		sparkReporter.config().setTimelineEnabled(true); // Enable timeline feature
		sparkReporter.config().setTheme(Theme.STANDARD); // Set the report theme

		extent = new ExtentReports(); // Initialize ExtentReports
		extent.attachReporter(sparkReporter); // Attach ExtentSparkReporter to ExtentReports
	}

	// Method executed after the test completes
	public void onFinish(ITestContext context) {
		extent.flush(); // Flush ExtentReports to write the report
	}

	// Method executed when a test passes
	public void onTestSuccess(ITestResult result) {
		test = extent.createTest(result.getName()); // Create ExtentTest for the test
		test.assignCategory(result.getMethod().getGroups()); // Assign categories to the test
		test.createNode(result.getName()); // Create a node for the test
		test.log(Status.PASS, "Test Passed"); // Log the test status as PASS
		ReusableFunction rf = new ReusableFunction();
		String screenshot = rf
				.takeScreenshot(System.getProperty("user.dir") + "\\Success_screenshots\\" + result.getName() + ".png");
		String screenshotPath = ReusableFunction
				.takeScreenshot(System.getProperty("user.dir") + "\\Success_screenshots\\" + result.getName() + ".png");
//		test.addScreenCaptureFromPath(screenshotPath);
		test.addScreenCaptureFromPath(screenshot, result.getName());
	}

	// Method executed when a test fails
	public void onTestFailure(ITestResult result) {
		test = extent.createTest(result.getName()); // Create ExtentTest for the test
		test.assignCategory(result.getMethod().getGroups()); // Assign categories to the test
		test.createNode(result.getName()); // Create a node for the test
		test.log(Status.FAIL, "Test Failed"); // Log the test status as FAIL
		test.log(Status.FAIL, result.getThrowable().getMessage()); // Log the failure message
//        To take screenshot
//		ReusableFunction rf = new ReusableFunction();
		String screenshot = ReusableFunction
				.takeScreenshot(System.getProperty("user.dir") + "/Failed_screenshots/result.getName() + \".png\"");
		test.fail(result.getThrowable()); // Log the error details
		// Capture and attach the screenshot
		String screenshotPath = ReusableFunction
				.takeScreenshot(System.getProperty("user.dir") + "\\Failed_screenshots\\" + result.getName() + ".png");
//		test.addScreenCaptureFromPath(screenshotPath);
		test.addScreenCaptureFromPath(screenshot, result.getName());

	}

	// Method executed when a test is skipped
	public void onTestSkipped(ITestResult result) {
		test = extent.createTest(result.getName()); // Create ExtentTest for the test
		test.assignCategory(result.getMethod().getGroups()); // Assign categories to the test
		test.createNode(result.getName()); // Create a node for the test
		test.log(Status.SKIP, "Test Skipped"); // Log the test status as SKIP
		test.log(Status.SKIP, result.getThrowable().getMessage()); // Log the skip message
	}
}
