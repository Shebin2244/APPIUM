package base;

import java.io.File;
import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.appium.java_client.android.AndroidDriver;

public class ReusableFunction {
	private static AndroidDriver driver;
	Properties properties;
	private WebDriverWait wait;
	static ExtentSparkReporter sparkReporter;
	static ExtentReports reports;
	ExtentTest test;

	// ********************* Get Text ***********************
	public String ReturnGetText(WebElement element) {
		waitForElementToDisplay(element);
		return element.getText();
	}

	public ReusableFunction(AndroidDriver driver) {
		ReusableFunction.driver = driver;
		wait = new WebDriverWait(ReusableFunction.driver, Duration.ofSeconds(10));
		properties = FileIO.getProperties("config");

	}

//	******************Get data from property file*********************
	public String getPropertyValue(String s) {

		return properties.getProperty(s);

	}

	public void tapByCoordinates(int x, int y) {
		PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		Sequence tap = new Sequence(finger, 1)
				.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(), x, y))
				.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
				.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		driver.perform(Collections.singletonList(tap));
	}

	public void clickOnElement(WebElement element) {
		waitForElementToDisplay(element);
		element.click();
	}

	public void waitForElementToDisplay(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void takeADelay(int i) {
		try {
			Thread.sleep(i * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public boolean isDisplayed(WebElement element) {
		waitForElementToDisplay(element);
		return element.isDisplayed();
	}

//	*****************Take ScreenShot******************
	public static String takeScreenshot(String filepath) {
		TakesScreenshot screenshot = (TakesScreenshot) driver;
		java.io.File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
		long filePath = System.currentTimeMillis();
		File destFile = new File(filepath + File.separator + filePath);

		try {
			FileUtils.copyFile(srcFile, destFile);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return filepath + File.separator + filePath;
	}

	public ReusableFunction() {
		properties = FileIO.getProperties("config");

	}

}
