package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class DeletePOM {
	private AndroidDriver driver;
	ReusableFunction rf;

	// Constructor to initialize the driver and reusable functions
	public DeletePOM(AndroidDriver driver) {
		this.driver = driver;
		rf = new ReusableFunction(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Finds the skip button by its id and allows it to be clicked
	@FindBy(id = "android:id/button2")
	WebElement skipButton;

	// Finds the allow button by its id and allows it to be clicked
	@AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_button")
	WebElement allowButton;

	// Finds the open search bar by its id and allows it to be clicked
	@AndroidFindBy(id = "com.google.android.contacts:id/open_search_bar")
	WebElement openSearchBar;

	// Finds the search bar text view by its id and allows it to be interacted with
	@AndroidFindBy(id = "com.google.android.contacts:id/open_search_bar_text_view")
	WebElement search;

	@AndroidBy(xpath = "//android.widget.TextView[@text='Delete']")
	WebElement delete;

	// Method to skip the permission and allow button
	public void skip() {
		rf.clickOnElement(skipButton); // Click the skip button
		rf.takeADelay(2); // Wait for 2 seconds
		rf.clickOnElement(allowButton); // Click the allow button
	}

	// Method to search for a contact named "shebin"
	public void search() {
		rf.takeADelay(3); // Wait for 3 seconds
		rf.tapByCoordinates(350, 222); // Tap to open the search bar
		// Entering the name "shebin" using coordinates
		rf.takeADelay(3); // Wait for 3 seconds
		rf.tapByCoordinates(223, 1849); // Tap 's'
		rf.tapByCoordinates(651, 1845); // Tap 'h'
		rf.tapByCoordinates(282, 1719); // Tap 'e'
		rf.tapByCoordinates(660, 1975); // Tap 'b'
		rf.tapByCoordinates(807, 1698); // Tap 'i'
		rf.tapByCoordinates(752, 1979); // Tap 'n'

		rf.takeADelay(2); // Wait for 2 seconds
		// Click on the listed contact
		rf.tapByCoordinates(287, 419);
	}

	// Method to check if the search bar is displayed
	public boolean searchBar() {
		return rf.isDisplayed(openSearchBar); // Check if the search bar is displayed
	}

	// Method to click on the settings option
	public void clickSettings() {
		rf.takeADelay(3); // Wait for 3 seconds
		rf.tapByCoordinates(1006, 234); // Tap on the settings option
	}

	// Method to delete a contact
	public void delete() {
		rf.takeADelay(3); // Wait for 3 seconds
		rf.tapByCoordinates(626, 382); // Tap to open delete confirmation
		rf.tapByCoordinates(830, 1355); // Tap to confirm deletion
	}

	public boolean deleteOption() {
		rf.takeADelay(3); // Wait for 3 seconds
		return rf.isDisplayed(delete);
	}
}
