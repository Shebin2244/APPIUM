package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunction;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class AccountCreatePOM {
	private AndroidDriver driver;
	ReusableFunction rf;

	// Constructor to initialize driver and reusable functions
	public AccountCreatePOM(AndroidDriver driver) {
		this.driver = driver;
		rf = new ReusableFunction(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Finds the skip button by its id and allows it to be clicked
	@FindBy(id = "android:id/button2")
	WebElement skipButton;

	// Finds the allow button by its id and allows it to be clicked
	@AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_button")
	WebElement allowButton;

	// Finds the contact title element by its id and allows it to be interacted with
	@AndroidFindBy(id = "com.google.android.contacts:id/navigation_bar_item_large_label_view")
	WebElement contactTitlElement;

	// Finds the add button by its accessibility id and allows it to be clicked
	@AndroidFindBy(accessibility = "Create contact")
	WebElement addButton;

	// Finds the create contact title element by its xpath and allows it to be interacted with
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.LinearLayout/android.view.ViewGroup/android.widget.TextView")
	WebElement createTitleElement;

	// Finds the save button by its id and allows it to be clicked
	@AndroidFindBy(id = "com.google.android.apps.photos:id/photos_photoeditor_fragments_editor3_save")
	WebElement saveButton;
	
	// Finds the name element by its id and allows it to be interacted with
	@AndroidBy(id = "com.google.android.contacts:id/large_title")
	WebElement nameElement;
	
	// Finds the organization element by its id and allows it to be interacted with
	@AndroidBy(id = "com.google.android.contacts:id/organization_name")
	WebElement organizationElement;

	// Method to skip the permission and allow button
	public void skip() {
		rf.clickOnElement(skipButton); // Click the skip button
		rf.takeADelay(2); // Wait for 2 seconds
		rf.clickOnElement(allowButton); // Click the allow button
	}

	// Method to get the title of the contact
	public String contactTitle() {
		return rf.ReturnGetText(contactTitlElement); // Return the text of the contact title element
	}

	// Method to click on the contacts button
	public void clickContacts() {
		rf.clickOnElement(addButton); // Click the add button
	}

	// Method to check if the add button is displayed
	public boolean addButton() {
		return rf.isDisplayed(addButton); // Check if the add button is displayed
	}

	// Method to get the title of the create contact page
	public String createContactTitle() {
		return rf.ReturnGetText(createTitleElement); // Return the text of the create contact title element
	}

	// Method to set text for multiple input fields dynamically
	public void setInputFieldsData(String... data) {
		for (int i = 0; i < data.length; i++) {
			driver.findElements(AppiumBy.className("android.widget.EditText")).get(i).sendKeys(data[i]); // Set text for each input field
		}
		rf.takeADelay(2); // Wait for 2 seconds
		rf.tapByCoordinates(834, 222); // Tap at specific coordinates to save the input
	}

	// Method to get the contact name
	public String conatctName() {
		return rf.ReturnGetText(nameElement); // Return the text of the name element
	}

	// Method to get the organization name
	public String organizationName() {
		return rf.ReturnGetText(organizationElement); // Return the text of the organization element
	}
}
