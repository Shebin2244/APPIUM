package testCase;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;

import org.apache.commons.io.FileUtils;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import base.DriverSetup;
import base.ExtentReportManager;
import io.cucumber.core.internal.com.fasterxml.jackson.core.type.TypeReference;
import io.cucumber.core.internal.com.fasterxml.jackson.databind.ObjectMapper;
import pom.AccountCreatePOM;

@Listeners(ExtentReportManager.class)
public class AccountCreateTest extends DriverSetup {
	AccountCreatePOM create;

	// This test starts the process by initializing the page object and skipping any
	// initial prompts.
	@Test(priority = 1)
	public void start() {
		create = new AccountCreatePOM(driver);
		create.skip();
	}

	// This test checks if the contact title on the page is "Contacts".
	@Test(priority = 2)
	public void contactTitleTest() {
		assertEquals(create.contactTitle(), "Contacts");
	}

	// This test verifies if the add button is present and clicks on the contacts
	// button.
	@Test(priority = 3)
	public void checkAddButtonAndaddContactTest() {
		assertTrue(create.addButton());
		create.clickContacts();
	}

	// This test checks if the title of the create contact page is "Create contact".
	@Test(priority = 4)
	public void createContactTest() {
		assertEquals(create.createContactTitle(), "Create contact");
	}

	// This test uses the Faker library to generate dummy data for adding contact
	// details (disabled).
	@Test(priority = 5, enabled = false, invocationCount = 1)
	public void addContactDetailsTest() {
		Faker faker = new Faker();
		String firstName = faker.name().firstName();
		String lastName = faker.name().lastName();
		String company = faker.company().name();
		String phoneNumber = faker.phoneNumber().cellPhone();
		String email = faker.internet().emailAddress();
		create.setInputFieldsData(firstName, lastName, company, phoneNumber, email);
	}

	// This test adds specific contact details (disabled).
	@Test(priority = 6, enabled = false)
	public void myContactAddDetails() {
		create.setInputFieldsData("shebin", "p biju", "UST", "(999) 581-5251", "shebin2244@gmail.com");
	}

	// This test reads contact data from a JSON file and adds it to the contact
	// form.
	@Test(priority = 6)
	public void myContactAdd() {
		try {
			HashMap<String, String> data = getJsonData(
					System.getProperty("user.dir") + "\\src\\main\\resources\\contactData.json");
			create.setInputFieldsData(data.get("firstname"), data.get("secondname"), data.get("organization"),
					data.get("phone"), data.get("email"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// This method reads JSON data from a file and converts it into a HashMap.
	public HashMap<String, String> getJsonData(String jsonFilePath) throws IOException {
		String jsonContent = FileUtils.readFileToString(new File(jsonFilePath), StandardCharsets.UTF_8);
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(jsonContent, new TypeReference<HashMap<String, String>>() {
		});
	}
}
