package testCase;

public class TestPOM {

}
