package stepdefinitions;

import static org.testng.Assert.assertTrue;

import base.ReusableFunction;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.DeletePOM;

public class AccountDeletionStepDefinition {
	public AndroidDriver driver = Hooks.driver;
	ReusableFunction rf;
	DeletePOM deletePOM;

	@Given("user is in conatct App")
	public void user_is_in_conatct_app() {
		rf = new ReusableFunction();
		deletePOM = new DeletePOM(driver);
	}

	@When("user skip the permission and allow button")
	public void user_skip_the_permission_and_allow_button() {
		deletePOM.skip();
	}

	@Then("user check search bar is present or not")
	public void user_check_search_bar_is_present_or_not() {
		assertTrue(deletePOM.searchBar(), "check search bar is not present");
	}

	@Then("enter the user name")
	public void enter_the_user_name() {
		deletePOM.search();
	}

	@When("user click on the settings")
	public void user_click_on_the_settings() {
		deletePOM.clickSettings();
	}

	@Then("user check delete option is available or not")
	public void user_check_delete_option_is_available_or_not() {
		assertTrue(deletePOM.deleteOption(), "check delete option is not available");
	}

	@Then("click the delete option")
	public void click_the_delete_option() {
		deletePOM.delete();
	}

}
