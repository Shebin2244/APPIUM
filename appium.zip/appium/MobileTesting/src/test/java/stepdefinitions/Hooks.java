package stepdefinitions;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Base64;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import base.ReusableFunction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {

	private ExtentReports extent;
	private ExtentTest test;
	public static AndroidDriver driver;
	static UiAutomator2Options options;
	ReusableFunction rf = new ReusableFunction();

	@Before
	public void open() throws MalformedURLException {

		options = new UiAutomator2Options();
		options.setDeviceName(rf.getPropertyValue("deviceName"));
		options.setPlatformName(rf.getPropertyValue("platformName"));

		if (rf.getPropertyValue("appType").equals("installed")) {
			options.setApp((rf.getPropertyValue("app")));
		} else {

			options.setAppPackage(rf.getPropertyValue("appPackage"));
			options.setAppActivity(rf.getPropertyValue("appActivity"));
		}

		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		ExtentSparkReporter reporter = new ExtentSparkReporter("extent.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		// create a new test
		test = extent.createTest("OrangeHrm");

	}

	@After
	public void closeBrowser(Scenario scenario) {
		if (scenario.isFailed()) {
			String screenshot = ReusableFunction
					.takeScreenshot(System.getProperty("user.dir") + "\\screenshot\\" + scenario.getName() + ".png");
			test.addScreenCaptureFromBase64String(screenshot);
			test.addScreenCaptureFromPath(screenshot);
		} else {
			// Take the screenshot
			final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			// Add it to the report
			test.addScreenCaptureFromPath("data:image/png;base64," + Base64.getEncoder().encodeToString(screenshot));
			test.pass("Test passed");
			test.log(Status.PASS, scenario.getName());
		}
		extent.flush();
		driver.quit();
	}

}
